# Chaitanya Mehta — Personal Website

Apple-inspired, editorial personal website for **Chaitanya Mehta — Trader, Founder and Investor**.

## Included
- `index.html` — complete website content and structure
- `styles.css` — responsive visual system
- `script.js` — small interaction layer

## Publish on GitHub Pages
1. Create a new GitHub repository, e.g. `chaitanya-mehta`.
2. Upload these three files to the repository root.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`.
6. Save. GitHub will publish the site.

## Before publishing
- Replace `hello@chaitanyamehta.com` in `index.html` with your actual public email.
- Add your preferred LinkedIn / Instagram / X links if desired.
- Review the investment and future-planning language for legal/compliance positioning before publishing.
- If you want to show verified trading performance publicly, add audited/verified figures rather than presenting account growth as a promise of future returns.

## Design direction
The site uses a minimalist, premium, Apple-inspired visual language: large typography, generous whitespace, monochrome palette, rounded cards, restrained motion and a strong editorial hierarchy. It is an original implementation and is not an Apple website clone.
